%% PRELIMINARY DESIGN OF HORIZONTAL AXIS WIND TURBINE BLADES
%
% Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This coda was developed during the curse of "Machines" in the bachelor
% level of Mechanic Engineering at Politecnico di Milano
%
% This code use the Betz Actuator Disk theory for a preliminary design of
% the diameter anche the speed rotation, according to the number of blades
% and the power to produce. The output figures allows you to select the
% best solutions for your application.
% This code do not automatically save the results because the script is
% very easy and fast to run.

clear variables
close all
clc

addpath('Functions')

disp('PRELIMINARY DESIGN OF HORIZONTAL WIND TURBINE BLADES')
disp('Statistic diagram with Betz theory')
disp(' ')
disp('Author: Oboe Daniele, Marinomi Andrea and Mastrandrea Sabino')
disp('Release: 1.0')

%% USER INPUT

%Boundary conditions of the site location
air.T = 15; %ait temperature [�C]
z = 900; %altitude from the sea level [m]
c1 = 10; %undisturbed wind speed [m/s]

%Mechanical Power to produce [W]
P_target = 360e3;

%% Other input data

%Air features
air.R = 287; % gas constant
%relation between altitude and air pressure
air.P = (1.01325 - z*10^(-4))*1e5; %air pressure [Pa]
air.rho = air.P/(air.R * (air.T + 273.15)); %air density [kg/m^3]

%linear interpolation for the air viscosity at your temperature
viscosity_T = [-50 0 20 50 100]; %reference temperature [�C]
viscosity_mu = [1.49 1.70 1.77 1.89 2.10].*1e-5; %reference voscosity [Pa*s]
%ait visvosity at the temperature T
air.mu = interp1(viscosity_T, viscosity_mu, air.T); % [Pa*s]

a = 1/3; %best induction factor from Betz theory

%load the statistics data of wind turbines
load('Statistic_diagram_data.mat')


%% STATISTICS DIAGRAMS

%3 blades
lambda_3_points = lambda_3_blade(:,1); %statistical points (x)
cp_3_points = lambda_3_blade(:,2); %statistical points (y)
coeff_3 = polyfit(lambda_3_points,cp_3_points,5); %approximate polynomial
x_3 = lambda_3_blade(1,1):0.1:lambda_3_blade(end,1); %approximate points (x)
y_3 = polyval(coeff_3,x_3); %approximate points (y)

%2 blades
lambda_2_points = lambda_2_blade(:,1);
cp_2_points = lambda_2_blade(:,2);
coeff_2 = polyfit(lambda_2_points,cp_2_points,5);
x_2 = lambda_2_blade(1,1):0.1:lambda_2_blade(end,1);
y_2= polyval(coeff_2,x_2);

%1 blade 
lambda_1_points = lambda_1_blade(:,1);
cp_1_points = lambda_1_blade(:,2);
coeff_1 = polyfit(lambda_1_points,cp_1_points,5);
x_1 = lambda_1_blade(1,1):0.1:lambda_1_blade(end,1);
y_1 = polyval(coeff_1,x_1);

figure
plot(x_3, y_3, 'LineWidth', 2)
hold on
grid on
plot(x_2, y_2, 'LineWidth', 2)
plot(x_1, y_1, 'LineWidth', 2)
legend('3 blades', '2 blades', '1 blade')
title('STATISTIC DIAGRAM')
xlabel('\lambda')
ylabel('Cp')

%% PRELIMINARY DESIGN OF DIAMETER AND SPEED ROTATION

%3 blades 
P_betz_3 = P_target./y_3; %Betz ideal power [W]
Ad_3 = 2*P_betz_3./(c1^3*air.rho); %actuator disk area [m^2]
D_3 = 2*sqrt(Ad_3/pi); %actuator disc diameter [m]
u = x_3.*c1; %periferical speed [m/s]
omega_3 = u./(D_3 / 2); %speed rotation [rad/s]
n_3 = 60.*omega_3./(2*pi); %speed rotation [rpm]

%2 blades
W_betz_2 = P_target./y_2; 
Ad_2 = 2*W_betz_2./(c1^3*air.rho);
D_2 = 2*sqrt(Ad_2/pi);
u = x_2.*c1;
omega_2 = u./(D_2/2);
n_2 = 60.*omega_2./(2*pi);

%1 blade
W_betz_1 = P_target./y_1; 
Ad_1 = 2*W_betz_1./(c1^3*air.rho);
D_1 = 2*sqrt(Ad_1/pi);
u = x_1.*c1;
omega_1 = u./(D_1/2);
n_1 = 60.*omega_1./(2*pi);

figure
subplot(1,2,1)
plot(x_3, D_3, 'LineWidth', 2)
hold on
grid on
plot(x_2, D_2, 'LineWidth', 2)
plot(x_1, D_1, 'LineWidth', 2)
legend('3 blades', '2 blades', '1 blade')
title(['DIAMETER, P = ' num2str(P_target/1000) ' kW'])
xlabel('\lambda') %Tip-speed ratio
ylabel('D [m]')

subplot(1,2,2)
plot(x_3, n_3, 'LineWidth', 2)
hold on
grid on
plot(x_2, n_2, 'LineWidth', 2)
plot(x_1, n_1, 'LineWidth', 2)
legend('3 blades', '2 blades', '1 blade')
title(['SPEED ROTATION, P = ' num2str(P_target/1000) ' kW'])
xlabel('\lambda')
ylabel('n [rpm]')

