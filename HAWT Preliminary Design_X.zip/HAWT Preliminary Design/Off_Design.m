%% OFF - DESIGN HORIZONTAL AXIS WIND TURBINE BLADES
%
% Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This code was developed during the course of "Machines"
% of Mechanical Engineering (bachelor degree) at Politecnico di Milano. 
% It also uses XFOIL - MATLAB interface developed by Rafael Oliveira.
%
% This code calculates the power produced by a wind turbine in off-design
% conditions. You have to copy in the Current Folder the Matlab file
% "Blade_Design_data.mat" created with the Design script, this file 
% contains all the blade design information. You can set the off-design 
% wind speed and the other variables to calculate the power produced. 

clear variables
close all
clc

addpath('Functions')

disp('PRELIMINARY DESIGN OF HORIZONTAL WIND TURBINE BLADES')
disp('Off-Design')
disp(' ')
disp('Author: Oboe Daniele, Marinomi Andrea and Mastrandrea Sabino')
disp('Release: 1.0')
disp(' ')

%% USER INPUT

c1 = 10; %off - design undisturbed wind speed [m/s]

%Air features
air.gamma = 1.4; % gamma = Cp / Cv
air.R = 287; %gas constant
air.T = 273.15+15; %ait temperature [K]
air.rho = 1.1162; %air density [kg/m^3]
air.mu = 1.75e-5; %air viscosity [kg * s / m]

%positions in which to plot the triangle of velocity (from the hub to the tip)
sec_plot_triangle = [1 3 5];
%this vector contains the position in which to plot the triangle of velocity.
%The number must be contained between 1 and the number of sections of the
%blade

dim_text_plot = 14; %text dimension of the plot axis, title and legend
dim_lines_plot = 2; %plot lines thickness 

%parameters for the calculation of the induction factor
toll = 0.0001; %tollerance on the induction factor increment
maxiter = 30; %max number of iterations for the induction factor calculation
max_errors = 6; %max number of errors due to XFoil convergencefor each cycle

visibility_Xfoil = false;
%false = do not show the XFoil window
%true = show the XFoil window

%% AUTOMATIC INPUT

%load the data of the blade
load('Blade_Design_data.mat');

%associate the blade bata loaded to the current variables for the script
blade.folder = blade_design.folder; %folder that contains the profiles
blade.name = blade_design.name; %name of the blade
blade.profiles = blade_design.profiles; %profiles in array and linspaced 
                                        %from the hub to the tip
l = blade_design.l; %chord [m]
Nbl = blade_design.Nbl; %number of blades
gamma = blade_design.gamma; %angle of design pitch [deg]
r = blade_design.r; %radius of each section fron the axis of rotation [m]
omega = blade_design.omega; %rotation speed [rad/s]
AR = blade_design.AR; %aspect ratio
S_blade = blade_design.S; %blade area [m^2]
efficiency = blade_design.efficiency; %mechanical and electrical efficiency
a_design = blade_design.a_design; %design induction factor

u = omega*r; %periferical speed [m/s]

D = 2*r(end); %wind turbine diameter [m]

%% PRE - ANALYSIS CHECKS

%check if the blase folder exist
if exist(blade.folder, 'dir')~=7
    error('Error: the blade folder selected do not exist')
end

%check if all the profiles exist inside the blade folder
for ii=1:length(blade.profiles)
    if exist([blade.folder '/' char(blade.profiles(ii))], 'file')~=2
        error(['Error: Profile ' char(blade.profiles(ii)) ' is missing from the folder'])
    end
end

if max(sec_plot_triangle) > length(blade.profiles)
    error('It is not possible plot the triangle of velocity. The number selected in "sec_prot_triangole" for the plot exceed the number of the blade sections.')
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CALCULATE THE INDUCTION FACTOR IN EACH SECTION

%initialize the vectors. The last letter "c" means cycle
a_od_c = zeros(length(r), maxiter); %induction factor in off design conditions for each section
Re_c = zeros(length(r), maxiter); %Reynolds number
Cl_c = zeros(length(r), maxiter); %Lift coefficient
Cd_c = zeros(length(r), maxiter); %Drag coefficient
w_c = zeros(length(r), maxiter); %Realtive wind speed [m/s]
c2_c = zeros(length(r), maxiter); %wind speed at the actuator disc (at the wind turbine) [m/s]
Ma_c = zeros(length(r), maxiter); %Mach number
beta_c = zeros(length(r), maxiter); %relative wind speed angle [deg]
alpha_c = zeros(length(r), maxiter); %angle of attack [deg]

%Final values of the same variables
a_od = zeros(length(r), 1);
Re = zeros(length(r), 1);
Cl = zeros(length(r), 1);
Cd = zeros(length(r), 1);
w = zeros(length(r), 1);
Ma = zeros(length(r), 1);
beta = zeros(length(r), 1);
alpha = zeros(length(r), 1);

wait_bar = waitbar(0, 'Wait. Induction factor calculation in progress...');
for ii = 1:length(r) %calculate the induction factor on the section ii
    
    [a_od(ii), Re(ii), Cl(ii), Cd(ii), w(ii), Ma(ii), beta(ii), alpha(ii)] = Induction_factor(toll, maxiter, l(ii), c1, u(ii), r(ii), air, blade, gamma(ii), ii, a_design, Nbl, AR, visibility_Xfoil, max_errors);
    
    waitbar(ii/length(r),wait_bar); %upgrade the waitbar
end
close(wait_bar)

%wind speed at the wind turbine for each section [m/s]
c2 = (1-a_od).*c1;

%% FOLDER AND FILE FOR DATA SAVING

%if the folder do not exist the software will create it.
if exist('Report Off-Design', 'dir')~=7
    mkdir('Report Off-Design');
end

%current data and time
report.data = clock;
if report.data(2)<10
    report.month = ['0' num2str(report.data(2))];
else
    report.month = num2str(report.data(2));
end
if report.data(3)<10
    report.day = ['0' num2str(report.data(3))];
else
    report.day = num2str(report.data(3));
end
if report.data(4)<10
    report.hours = ['0' num2str(report.data(4))];
else
    report.hours = num2str(report.data(4));
end
if report.data(5)<10
    report.min = ['0' num2str(report.data(5))];
else
    report.min = num2str(report.data(5));
end
if report.data(6)<10
    report.sec = ['0' num2str(floor(report.data(6)))];
else
    report.sec = num2str(floor(report.data(6)));
end

%Design report folder
report.folder = ['Report Off-Design/' num2str(report.data(1)) '-' report.month '-' ...
    report.day ' ' report.hours '-' report.min '-' report.sec ' - ' blade.name];
mkdir(report.folder); %create the folder

%create the text file
report.file_name = [report.folder '/Off-Design data.txt'];
report.fileID = fopen(report.file_name, 'w');

fprintf(report.fileID, 'OFF-DESIGN REPORT ANALYSIS\r\n\r\n');
fprintf(report.fileID, 'Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino\r\n\r\n');
fprintf(report.fileID, 'Software release: 1.0\r\n\r\n');
fprintf(report.fileID, 'Blade: %s \r\n\r\n', blade.name);
fprintf(report.fileID, 'Data: %d-%s-%s \r\n', report.data(1), report.month, report.day);
fprintf(report.fileID, 'Time: %s:%s:%s \r\n\r\n', report.hours, report.min, report.sec);
fprintf(report.fileID, 'Analysis data: \r\n');
fprintf(report.fileID, '   Rotor diameter: D = %.2f m \r\n', D);
fprintf(report.fileID, '   r/R ratio = %.2f \r\n', r(1)/r(end));
fprintf(report.fileID, '   Undisturbed wind speed: c1 = %.2f m/s \r\n', c1);
fprintf(report.fileID, '   Speed rotation: omega = %.4f rad/s \r\n', omega);
fprintf(report.fileID, '   Tollerance on the chord increment: %.7f m\r\n', toll);
fprintf(report.fileID, '   Max number of iterations for the chord: %d m\r\n\r\n', maxiter);


%% WIND TURBINE POWER

beta_rad = beta * pi / 180;

%power with trapezes integral
[P_trap, P_ideal, Cp_trap, P_sup_trap] = Power_trapezes(r, l, beta_rad, c1, w, Cl, Cd, air, omega, Nbl, efficiency, report, dim_text_plot);

%power with Cavalieri-Simpson integral
[P_cs, P_ideal, Cp_cs] = Power_cs(r, l, beta_rad, c1, w, Cl, Cd, air, omega, Nbl, efficiency, report, dim_text_plot, true);

%% FIGURES

fig = figure;
plot(r, a_od, 'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('r [m]')
ylabel('a')
title('INDUCTION FACTOR')
ax = gca;
ax.FontSize = dim_text_plot;
saveas(fig, [report.folder '/Induction factor.jpg'], 'jpg');
saveas(fig, [report.folder '/Induction factor.fig'], 'fig');

fig = figure;
plot(r, alpha,'b-o', 'LineWidth', dim_lines_plot);
grid on
title('ANGLE OF ATTACK')
xlabel('r [m]')
ylabel('\alpha [deg]')
ax = gca;
ax.FontSize = dim_text_plot;
saveas(fig, [report.folder '/Angle of attack.jpg'], 'jpg');
saveas(fig, [report.folder '/Angle of attack.fig'], 'fig');

fig = figure;
subplot(311)
plot(r, Cl,'b-o', 'LineWidth', dim_lines_plot);
grid on
title('LIFT')
xlabel('r [m]')
ylabel('CL')
ax = gca;
ax.FontSize = dim_text_plot;

subplot(312)
plot(r, Cd,'b-o', 'LineWidth', dim_lines_plot);
grid on
title('DRAG')
xlabel('r [m]')
ylabel('CD')
ax = gca;
ax.FontSize = dim_text_plot;

subplot(313)
plot(r, Cl./Cd,'b-o', 'LineWidth', dim_lines_plot);
grid on
title('Cl / Cd ratio')
xlabel('r [m]')
ylabel('CL/CD')
ax = gca;
ax.FontSize = dim_text_plot;
saveas(fig, [report.folder '/Lift and Drad.jpg'], 'jpg');
saveas(fig, [report.folder '/Lift and Drag.fig'], 'fig');

%% PLOT TRIANGLE OF VELOCITY

for ii=1:length(sec_plot_triangle)
    profile_plot = [blade.folder '/' char(blade.profiles((sec_plot_triangle(ii))))];
    nama_profile_plot = char(blade.profiles((sec_plot_triangle(ii))));
    
    [fig] = velocity_triangle(c2(sec_plot_triangle(ii)), omega, r(sec_plot_triangle(ii)),...
        l(sec_plot_triangle(ii)), gamma(sec_plot_triangle(ii)), profile_plot, nama_profile_plot);
    
    %figure save
    saveas(fig, [report.folder '/Velocity triangle_ R ' num2str(r(sec_plot_triangle(ii))) ' m.jpg'], 'jpg');
    saveas(fig, [report.folder '/Velocity triangle_ R ' num2str(r(sec_plot_triangle(ii))) ' m.fig'], 'fig');
end


%% PROFILES OUTPUT IN THE REPORT FILE

fprintf(report.fileID, 'Profiles of the blade used\r\n');
fprintf(report.fileID, 'section   -   profile\r\n');
for ii=1:length(blade.profiles) 
    section = char(blade.profiles(ii));
    fprintf(report.fileID, '   %d    -    %s \r\n', ii, section(1:end-4));
end

%% END FUNCTION

fclose(report.fileID); %close the report file

%delete some unnecessary variables
clear fig ax wait_bar line_plot legend_line alpha_input alpha_opt ans cd_2D
clear coordinates_profile dim_lines_plot dim_text_plot h h_section ii
clear index jj legend_text section sol visibility_Xfoil
%save all the variables on a Matlab file
save([report.folder '/Analysis_data.mat'])


