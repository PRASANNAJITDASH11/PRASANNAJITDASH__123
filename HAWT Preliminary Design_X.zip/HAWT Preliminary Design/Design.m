%% PRELIMINARY DESIGN OF HORIZONTAL AXIS WIND TURBINE BLADES
%
% Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This code was developed during the course of "Machines" (bachelor in 
% Mechanical Engineering) at Politecnico di Milano. 
% It also uses XFOIL - MATLAB interface developed by Rafael Oliveira.
%
% This code can make a preliminary design of a wind turbine blade according to the
% boundary condition (wind speed, power, ...). In the first section of the
% code you can set all the data for the analysis (parameters for the
% iterations cycle, induction factors, wind speed, diameter, ...), in the
% second you can customize your blade selecting the airfoil that you
% prefer. You can pick together different airfoils to find the best
% solutions for your application.

clear variables
close all
clc

addpath('Functions')

disp('PRELIMINARY DESIGN OF HORIZONTAL WIND TURBINE BLADES')
disp('Blade design')
disp(' ')
disp('Author: Oboe Daniele, Marinomi Andrea and Mastrandrea Sabino')
disp('Release: 1.0')
disp(' ')

%% DATA INPUT

Nbl = 3; %number of blades
D = 50; %diameter [m]
lambda = 7; % tip-speed ratio
efficiency = 1; %Mechanical and electrical wind turbine efficiency

a = 0.275; %induction factor, a = 1/3 for ideal conditions (this code will 
%correct the drag coefficient and the conditions won't be ideal anymore,
%however the induction factor will be still near 1/3)
c1 = 12; %undisturbed wind speed [m/s]
omega = 2*lambda*c1/D; %rotation speed [rad/s]

r_R = 0.2; %external radius / internal radius ratio (r / R)

toll = 0.0001; %tollerance on the chord increase [m] (we suggest to use 0.0001 for a good result)
maxiter = 15; %number of max iterations on the chord

%Air features
air.gamma = 1.4; % gamma = Cp / Cv
air.R = 287; %gas constant
air.T = 273.15 + 15; %air temperature [K]
air.rho = 1.1162; %air density [kg/m^3]
air.mu = 1.75e-5; %air viscosity [kg * s / m]

visibility_Xfoil = false;
%false = do not show the XFoil window
%true = show the XFoil window

%angle of attack
alpha.start = 0; %start value of the angle of attack
alpha.finish = 20;  %finish value of the angle of attack
alpha.cycle_1 = 1; %step of the first cycle (we suggest to use 1 as step)
alpha.cycle_2 = 0.2; %step of the second cycle: this value must be a submultiple
        %of the first cycle step (we suggest to use one of the following 
        %values: 0.1, 0.2, 0.25)
        
%chord dimension for the first iterative cycle
l_0_max = 3; %chord dimension on the first section (hub) [m]
l_0_min = 0.5; %chord dimension on the last section (tip) [m]

dim_text_plot = 14; %text dimension of the plot axis, title and legend
dim_lines_plot = 2; %plot lines thickness 

%% BLADES DATABASE

% All the profiles used for the blade must be contained in the folder
% selected with the variable "blade.folder". The variable "blade.name" is a
% label with the name of the blade, you can put the name that you prefer.
% This name will be used for identify the the folder in which the results
% will be automatically saved.
% You can add a new blade adding a new line in the menu and a new case with
% the corresponding characteristics in the switch

%menu for the blade selection
blade_number = menu('SELECT THE BLADE', ...
    'Blade 1: 3 sections DU99W405LM and NACA64618',...    
    'Blade 2: 4 sections NREL',...  
    'Blade 3: 4 sections NREL',...   
    'Blade 4: 3 sections NREL',...         
    'Blade 5: 3 sections NREL',...
    'Blade 6: S814 S825 S826 interpolated with 38 profiles');
                                           
%Blade load
switch blade_number
    case 1 % Blade 1: 3 sections DU99W405LM and NACA64618
        blade.folder = 'Standard Profiles'; %folder that contains the profiles
        blade.name = 'Blade 1'; %name of the blade
        blade.profiles = {'DU97W300LM.dat','DU91W2250LM.dat','NACA64618.dat'}; %profiles
            % in array and linspaced fron the hub to the tip
    case 2 % Blade 2: 4 sections NREL
        blade.folder = 'Standard Profiles';
        blade.name = 'Blade 2';
        blade.profiles = {'s814.dat', 's809.dat','s810.dat'};
    case 3 % Blade 3: 4 sections NREL
        blade.folder = 'Standard Profiles';
        blade.name = 'Blade 3';
        blade.profiles = {'s814.dat', 's812.dat', 's813.dat'};
    case 4 % Blade 4: 3 sections NREL
        blade.folder = 'Standard Profiles';
        blade.name = 'Blade 4';
        blade.profiles = {'s818.dat','s816.dat','s817.dat'};
    case 5 % Blade 5: 3 sections NREL
        blade.folder = 'Standard Profiles';
        blade.name = 'Blade 5';
        blade.profiles = {'S814.dat', 'S825.dat', 'S826.dat'};
    case 6 % Blade 6: S814 S825 S826 interpolated with 38 profiles
        %This is the final blade we have designed during our project.
        blade.folder = 'S814_825_826_interpolated_38';
        blade.name = 'Final blade';
        blade.profiles = {'s814.dat','s814825_95.dat','s814825_90.dat','s814825_85.dat','s814825_80.dat','s814825_75.dat',...
            's814825_70.dat','s814825_65.dat','s814825_60.dat','s814825_55.dat','s814825_50.dat','s814825_45.dat',...
            's814825_40.dat','s814825_35.dat','s814825_30.dat','s814825_25.dat','s814825_20.dat','s814825_15.dat',...
            's814825_10.dat','s814825_5.dat','s825.dat','s825826_95.dat','s825826_90.dat','s825826_85.dat',...
            's825826_80.dat','s825826_75.dat','s825826_70.dat','s825826_65.dat','s825826_60.dat','s825826_55.dat',...
            's825826_50.dat','s825826_45.dat','s825826_40.dat','s825826_35.dat','s825826_30.dat','s825826_25.dat',...
            's825826_20.dat','s825826_15.dat','s825826_10.dat','s825826_5.dat','s826.dat'};
        
    otherwise
        error('The blade selected do not exist in the database')
end

%% PRE - ANALYSIS CHECKS

%check if the blase folder exist
if exist(blade.folder, 'dir')~=7
    error('Error: the blade folder selected do not exist')
end

%check if all the profiles exist inside the blade folder
for ii=1:length(blade.profiles)
    if exist([blade.folder '/' char(blade.profiles(ii))], 'file')~=2
        error(['Error: Profile ' char(blade.profile(ii)) ' is missing from the folder'])
    end
end

%% DESIGN

% Recalls the function for the preliminary blade design
[blade_design] = Blade_Design(blade, Nbl, D, omega, air, efficiency, a, c1, r_R, alpha, toll, maxiter, l_0_max, l_0_min, dim_text_plot, dim_lines_plot, visibility_Xfoil);

