function [P, P_ideal, Cp, P_sup] = Power_trapezes(r, l, beta, c1, w, Cl, Cd, air, omega, Nbl, efficiency, report, dim_text_plot)
% TRAPEZES INTEGRAL TO CALCULATE THE PRODUCED POWER
%
% Authors: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Date: October 14, 2017
% Release: 1.0
%
% Note: the wind speed angle beta must be setted in radiants [rad]

%disk actuator ideal power [W]
P_ideal = 0.5*pi*(r(end))^(2)*c1^3*air.rho;

P_section = zeros(1,length(r)); %power array
Area_section = zeros(1,length(r)); %blade area between two sections array

for ii = 2:length(r)    
    h_section = r(ii) - r(ii-1);
    
    %power produced in the area ii [W]
    P_section(ii) = (( (l(ii)*w(ii)^2*(Cl(ii)*cos(beta(ii)) - ...
        Cd(ii)*sin(beta(ii)))*r(ii)*h_section) +...
        (l(ii-1)*w(ii-1)^2*(Cl(ii-1)*cos(beta(ii-1)) - ...
        Cd(ii-1)*sin(beta(ii-1)))*r(ii-1)*h_section) ) / 2 ) *0.5*air.rho*omega;
    
    %ii blade area [m^2]
    Area_section(ii) = (l(ii-1)+ l(ii))*(r(ii)-r(ii-1))/2;
end

%Wind turbine power [W]
P = sum(P_section)*Nbl*efficiency;
%Cp
Cp = P/P_ideal;
%Power per unit of area [W/m^2]
P_sup = P_section ./ Area_section;

%output results
disp(' ')
disp('Power with trapezes equation')
disp(['   Power = ' num2str(P/1000) ' kW'])
disp(['   Cp = ' num2str(Cp)])

%writing the results in the report file
fprintf(report.fileID, 'Power with trapezes equation\r\n');
fprintf(report.fileID, '   Power = %.3f kW\r\n', P/1000);
fprintf(report.fileID, '   Cp = %.4f \r\n', Cp);

fig = figure;
x_trapezes = linspace(r(1),r(end),((length(r)*2)-1));
x_trapezes_index = 2:2:length(x_trapezes);
bar(x_trapezes(x_trapezes_index),P_section(2:end)/1000)
title('POWER: trapezes equation')
xlabel('r [m]')
ylabel('P [kW]')
ax = gca;
ax.FontSize = dim_text_plot;
%figure saving
saveas(fig, [report.folder '/Power trapezes.jpg'], 'jpg');
saveas(fig, [report.folder '/Power trapezes.fig'], 'fig');

fig = figure;
x_trapezes = linspace(r(1),r(end),((length(r)*2)-1));
x_trapezes_index = 2:2:length(x_trapezes);
bar(x_trapezes(x_trapezes_index),P_sup(2:end)/1000)
title('POWER PER UNIT OF AREA')
xlabel('r [m]')
ylabel('P [kW/m^2]')
ax = gca;
ax.FontSize = dim_text_plot;
%figure saving
saveas(fig, [report.folder '/Power per unit of area.jpg'], 'jpg');
saveas(fig, [report.folder '/Power per unit of area.fig'], 'fig');

end

