function [a_od, Re, Cl, Cd, w, Ma, beta, alpha] = Induction_factor(toll, maxiter, l, c1, u, r, air, blade, gamma, ii, a_design, Nbl, AR, visibility_Xfoil, max_errors)
% INDUCTION FACTOR CALCULATION
%
% Authors: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Date: October 14, 2017
% Release: 1.0

%initializing the vectors. The last letter "c" stands for cycle
a_od_c = zeros(1, maxiter); %induction factor in off design conditions
Re_c = zeros(1, maxiter); %Reynolds number
Cl_c = zeros(1, maxiter); %Lift coefficient
Cd_c = zeros(1, maxiter); %Drag coefficient
w_c = zeros(1, maxiter); %Relative wind speed [m/s]
c2_c = zeros(1, maxiter); %wind speed at the disk actuator (at the wind turbine) [m/s]
Ma_c = zeros(1, maxiter); %Mach number
beta_c = zeros(1, maxiter); %relative wind speed angle [deg]
alpha_c = zeros(1, maxiter); %angle of attack [deg]

counter = 1;
err = toll + 1; %setting err > toll to start the cycle
a_od_c(1) = a_design; %setting the first induction factor

%iterative cycle to calculate the induction factor
while err>toll && counter<=maxiter
    counter = counter+1;

    %wind speed at the wind turbine [m/s]
    c2_c(counter) = (1-a_od_c(counter-1))*c1;

    error = true; %setting true to start the cycle
    counter_error = 0; %counter for the errors in Xfoil (when XFoil doesn't
                       %converge)

    while error == true

        w_c(counter) = (u^2 + c2_c(counter)^2)^0.5; %relative wind speed
        beta_c(counter) = atand(u / c2_c(counter)); %relative wind angle
        alpha_c(counter) = gamma - beta_c(counter); %angle of attack

        Re_c(counter) = air.rho*w_c(counter)*l/air.mu; %Reynolds number
        Ma_c(counter) = w_c(counter)/(sqrt(air.gamma*air.R*air.T)); %Mach number

        %Recalling Xfoil to evaluate the Lift and Drag coefficients
        data_profile = XFoil_launcher(Re_c(counter), Ma_c(counter), alpha_c(counter),...
            [blade.folder '/' char(blade.profiles(ii))], visibility_Xfoil);

        if isempty(data_profile.CL)==0 %XFoil converged
            Cl_c(counter) = data_profile.CL;
            cd_2D = data_profile.CD;
            Cd_c(counter) = cd_2D + (Cl_c(counter)^2)/(pi*AR); %Cd with 3D correction
            error = false; %do not recall XFoil again for this blade section
        else %XFoil didn't converge
            error = true; %recalling XFoil again for this blade section
            %The code slightly modifies the input,trying to reach
            %convergence with a small error
            c2_c(counter) = c2_c(counter)*1.001;
            counter_error = counter_error + 1;
            disp(['WARNING: XFoil attempt n. ' num2str(counter_error) ' didn''t converge.'])
            if counter_error == max_errors
                if counter > 1
                    %setting the Drag and Lift coefficients calculated in
                    %the previous iterative cycle
                    Cl_c(counter) = Cl_c(counter-1);
                    Cd_c(counter) = Cd_c(counter-1);
                    error = false; %do not recall XFoil again for this blade section
                    warning('XFoil convergence failed. Reached the max number of errors allowed.')
                else
                    %sorry, we can't solve the problem...
                    error('XFoil convergence failed. Reached the max number of errors allowed.')
                end

            end
        end
    end

    %calculating the off - design induction factor for this cycle
    a_od_c(counter) = l / ( l + (8*pi*r*c2_c(counter)^2)/(Nbl*w_c(counter)^2*...
        ( Cl_c(counter)*sind(beta_c(counter)) + Cd_c(counter)*cosd(beta_c(counter)) )) );

    if a_od_c(counter) > 0.5 
        a_od_c(counter) = 0.5;
        break;
    end

    %error on the induction factor increment
    err = abs(a_od_c(counter-1) - a_od_c(counter));
    
    if counter == (maxiter+1)
        warning('Reach the max number of iterations')
    end
end

%assigning the calculated values to the variables
a_od = a_od_c(counter);
Re = Re_c(counter);
Cl = Cl_c(counter);
Cd = Cd_c(counter);
w = w_c(counter);
Ma = Ma_c(counter);
beta = beta_c(counter);
alpha = alpha_c(counter);


end

