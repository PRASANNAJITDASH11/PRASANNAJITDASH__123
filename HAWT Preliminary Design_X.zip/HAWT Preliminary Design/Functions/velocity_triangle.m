function [fig] = velocity_triangle(c2, omega, r, l, gamma, profile, name)
% VELOCITY TRIANGLE FOR A HORIZONTAL AXIS WIND TURBINE 
%
% Authors: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This function creates a figure with the velocity triangle previously
% calculated.
%
% INPUT:
%       c2 = wind speed at the blade [m/s]
%       omega = wind turbine rotational speed [rad/s]
%       r = radial coordinate (distance between the section and the rotation axis) [m]
%       l = chord length [m]
%       gamma = pitch angle for each section [deg]
%       profile = string with the profile name. Extensions allowed: .dat 
%                   or .mat(for example: 's814.dat')
%       name = section name
% OUTPUT:
%       fig = struct with figure data

%% DATA INPUT to customize the plot

gamma_original = gamma;
gamma = 90 - gamma; %changing the reference system
gamma = gamma*pi/180; %pitch angle [rad]

%coefficients for the plot
f_scale = 0.8; %scale factor for the velocity dimension in relation to the profile dimension
f_figure_x = 0.05; %scale factor for the x axis
f_figure_y = 0.2; %scale factor for the y axis
dim_vet = 0.03; %dimension of the arrow in relation to the max arrow line length
th_vector = 3; %vector line's thickness 
th_blade = 3; %blade section line's thickness 
text_dimension = 11; %text dimension

%% FIGURE CREATION

%input profile data
coordinates_prodfile = load(profile);

x_profile = coordinates_prodfile(:,1);
y_profile = coordinates_prodfile(:,2);
 
%index of the min value of x
index_x_min = find(x_profile == min(x_profile));

%profile traslation: creates a coincidence between the center of the
%profile and the y axis
x_profile = x_profile*l - 0.5*l;
y_profile = y_profile*l;

%profile rotation with the pitch angle
for ii=1:length(x_profile)
    sol = [cos(gamma) -sin(gamma); ...
        sin(gamma) cos(gamma)] * [x_profile(ii); y_profile(ii)];
    x_profile(ii) = sol(1);
    y_profile(ii) = sol(2);
end

%peripheral speed [m/s]
u = omega*r;

%normalizing the vector's dimensions
u_norm = u * l * f_scale / max([u c2]);
v_norm = c2 * l * f_scale / max([u c2]);

beta = atan(u/c2); %relative wind speed angle [rad]

fig = figure;
plot(x_profile, y_profile, 'k', 'LineWidth', th_blade)
axis equal
grid on
hold on
legend_line(1) = plot([x_profile(index_x_min) x_profile(index_x_min)], [y_profile(index_x_min) y_profile(index_x_min)-v_norm], 'b', 'LineWidth', th_vector);
legend_line(2) = plot([x_profile(index_x_min) x_profile(index_x_min)-u_norm], [y_profile(index_x_min) y_profile(index_x_min)], 'r', 'LineWidth', th_vector);
legend_line(3) = plot([x_profile(index_x_min) x_profile(index_x_min)-u_norm], [y_profile(index_x_min) y_profile(index_x_min)-v_norm], 'g', 'LineWidth', th_vector);

legend_text{1} = 'V';
legend_text{2} = 'U';
legend_text{3} = 'W';
legend(legend_line, legend_text, 'Location', 'southeast')
title(['PROFILE: ' name(1:end-4) '     l = ' num2str(l) ' m     c2 = ' num2str(c2) ...
    ' m/s     n = ' num2str(omega*30/pi) ' rpm     \gamma = ' num2str(gamma_original) ...
    '�    r = ' num2str(r) ' m'])

%plot the vectors
dim_arrow = max([u_norm v_norm])*dim_vet;
x_vect_v = [x_profile(index_x_min) x_profile(index_x_min)+dim_arrow ...
    x_profile(index_x_min)-dim_arrow x_profile(index_x_min)];
y_vect_v = [y_profile(index_x_min) y_profile(index_x_min)-dim_arrow ...
    y_profile(index_x_min)-dim_arrow y_profile(index_x_min)];
x_vect_u = [x_profile(index_x_min)-u_norm x_profile(index_x_min)-u_norm+dim_arrow ...
    x_profile(index_x_min)-u_norm+dim_arrow x_profile(index_x_min)-u_norm];
y_vett_u = [y_profile(index_x_min) y_profile(index_x_min)+dim_arrow ...
    y_profile(index_x_min)-dim_arrow y_profile(index_x_min)];
x_vect_w = [x_profile(index_x_min) x_profile(index_x_min)+dim_arrow ...
    x_profile(index_x_min)-dim_arrow x_profile(index_x_min)];
y_vect_w = [y_profile(index_x_min) y_profile(index_x_min)-dim_arrow ...
    y_profile(index_x_min)-dim_arrow y_profile(index_x_min)];
for ii=1:length(x_vect_w) %arrow rotation
    sol = [cos(-beta) -sin(-beta); sin(-beta) cos(-beta)] * ...
        [x_vect_w(ii)-x_profile(index_x_min); y_vect_w(ii)-y_profile(index_x_min)];
    x_vect_w(ii) = sol(1)+x_profile(index_x_min);
    y_vect_w(ii) = sol(2)+y_profile(index_x_min);
end

plot(x_vect_v, y_vect_v, 'b', 'LineWidth', th_vector);
plot(x_vect_u, y_vett_u, 'r', 'LineWidth', th_vector);
plot(x_vect_w, y_vect_w, 'g', 'LineWidth', th_vector);

%chord plot
plot([x_profile(index_x_min) x_profile(1)], [y_profile(index_x_min) y_profile(1)], 'k--', 'LineWidth', 1.2)

%axis dimension
X_min = x_profile(index_x_min)-u_norm - (max(x_profile)-(x_profile(index_x_min)-u_norm)) * f_figure_x;
X_max = max(x_profile) + (max(x_profile)-(x_profile(index_x_min)-u_norm)) * f_figure_x;
Y_min = min([y_profile(index_x_min)-v_norm min(y_profile)]) - (max(y_profile)-min([y_profile(index_x_min)-v_norm min(y_profile)])) * f_figure_y;
Y_max = max(y_profile) + (max(y_profile)-(min([y_profile(index_x_min)-v_norm min(y_profile)]))) * f_figure_y;

axis([X_min X_max Y_min Y_max])

ax = gca;
ax.FontSize = text_dimension; %text dimension


end

