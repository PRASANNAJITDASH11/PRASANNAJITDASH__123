function [P, P_ideal, Cp] = Power_cs(r, l, beta, c1, w, Cl, Cd, air, omega, Nbl, efficiency, report, dim_text_plot, output_data)
% CAVALIERI-SIMPSON INTEGRAL TO CALCULATE THE PRODUCED POWER
%
% Authors: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Date: October 14, 2017
% Release: 1.0
%
% Note: the wind speed angle beta must be set in radiants [rad]

%Disk actuator ideal power [W]
P_ideal = 0.5*pi*(r(end))^(2)*c1^3*air.rho;

%The integral of a function f(x) , calculated in the interval [a,b] with Cavalieri - Simpson method , is:
%Integral = (f(a)/3 + 4*f((b+a)/2)/3 + f(b)/3 )*(b-a)/2

if length(r)/2 ~= round( length(r)/2 ) %odd number of sections
P_section = zeros(1,length(r)); 
    for ii = 3 : 2 : length(r) 
    h_section = r(ii) - r(ii-2);
    %power produced in the area ii [W]
    P_section(ii) = (( (l(ii)*w(ii)^2*(Cl(ii)*cos(beta(ii)) - ...
        Cd(ii)*sin(beta(ii)))*r(ii)) +...
        4*(l(ii-1)*w(ii-1)^2*(Cl(ii-1)*cos(beta(ii-1)) - ...
        Cd(ii-1)*sin(beta(ii-1)))*r(ii-1))+...
        (l(ii-2)*w(ii-2)^2*(Cl(ii-2)*cos(beta(ii-2)) - ...
        Cd(ii-2)*sin(beta(ii-2)))*r(ii-2)))*h_section / 6 ) *0.5*air.rho*omega;
    end
else %even number of sections --> the last value is evaluated with the trapezes equation
P_section = zeros(1,length(r)); 
    for ii = 3 : 2 : (length(r) - 1)
    h_section = r(ii) - r(ii-2);
    P_section(ii) = (( (l(ii)*w(ii)^2*(Cl(ii)*cos(beta(ii)) - ...
        Cd(ii)*sin(beta(ii)))*r(ii)) +...
        4*(l(ii-1)*w(ii-1)^2*(Cl(ii-1)*cos(beta(ii-1)) - ...
        Cd(ii-1)*sin(beta(ii-1)))*r(ii-1))+...
        (l(ii-2)*w(ii-2)^2*(Cl(ii-2)*cos(beta(ii-2)) - ...
        Cd(ii-2)*sin(beta(ii-2)))*r(ii-2)))*h_section / 6 )*0.5*air.rho*omega;
    end
    h_section = r(end) - r(end-1);
    P_section(end) = (( (l(end)*w(end)^2*( Cl(end)*cos(beta(end)) - ...
        Cd(end)*sin(beta(end)) )*r(end)*h_section) +...
        ( l(end-1)*w(end-1)^2*( Cl(end-1)*cos(beta(end-1)) - ...
        Cd(end-1)*sin(beta(end-1)) )*r(end-1)*h_section) ) / 2 )*0.5*air.rho*omega;
end

%wind turbine power
P = sum(P_section)*Nbl*efficiency;
%Cp with Cavalieri - Simpson power
Cp = P/P_ideal;

if output_data == true

    %output results
    disp('Power with Cavalieri-Simpson equation')
    disp(['   Power = ' num2str(P/1000) ' kW'])
    disp(['   Cp = ' num2str(Cp)])

    %writing the results in the report file
    fprintf(report.fileID, 'Power with Cavalieri-Simpson equation\r\n');
    fprintf(report.fileID, '   Power = %.3f kW\r\n', P/1000);
    fprintf(report.fileID, '   Cp = %.4f \r\n\r\n', Cp);

    fig = figure;
    x_cavalieri = linspace(r(1),r(end),((length(r)*2)-1));
    x_cavalieri_index = 2:2:length(x_cavalieri);
    bar(x_cavalieri(x_cavalieri_index),P_section(2:end)/1000)
    title('POWER: Cavalieri-Simpson equation')
    xlabel('r [m]')
    ylabel('P [kW]')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %saving figure
    saveas(fig, [report.folder '/Power Cavalieri Simpson.jpg'], 'jpg');
    saveas(fig, [report.folder '/Power Cavalieri Simpson.fig'], 'fig');

end

end

