function [blade_design] = Blade_Design(blade, Nbl, D, omega, air, efficiency, a, c1, r_R, alpha_struct, toll, maxiter, l_0_max, l_0_min, dim_text_plot, dim_lines_plot, visibility_Xfoil)
%% PRELIMINARY DESIGN OF HORIZONTAL AXIS WIND TURBINE BLADES
%
% Authors: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Date: October 14, 2017
% Release: 1.0
%
% This code was developed during the course of "Machines" in the bachelor
% level of Mechanical Engineering at Politecnico di Milano. 
% It also uses XFOIL - MATLAB interface developed by Rafael Oliveira.
%
% This script uses XFoil and your input data to create a preliminary blade
% design.

%% DATA INPUT

c2 = (1-a)*c1; %wind speed at the disk actuator (at the wind turbine) [m/s]

% Vector with the radial coordinates, in which the software evaluates the chord.
% The sections are equally spaced between the hub and tip
% radius, according whith the number of profiles.
r = D*0.5*linspace(r_R,1,length(blade.profiles)); %[m]

%vectors that contain a value for each section at the radius r
l_0 = linspace(l_0_max, l_0_min, length(r)); %first try chord [m]
u = omega*r; %peripheral speed [m/s] 
w = sqrt(u.^2 + c2.^2); %relative wind speed [m/s]
Ma = w/(sqrt(air.gamma*air.R*air.T)); %Mach number
beta = atan(u/c2); %relative wind speed angle [rad]
beta_deg = beta*180/pi; %relative wind speed angle [deg]


%% CHORD CALCULATION

err = (toll+1); % setting err > toll to start the cycle
counter = 2;
h = r(end) - r(1); %blade length

%Matrix that contains the coefficients during the iteration. Each matrix has
%a number of row equal to the number of the blade sections and a number of
%columns equal to the max iteration number. The data of each
%iteration are saved in a different column.
Re = zeros(length(r), maxiter+1); %Reynolds number
Cl = zeros(length(r), maxiter+1); %Lift coefficient
Cd = zeros(length(r), maxiter+1); %Drag coefficient
alpha = zeros(length(r), maxiter+1); %Angle of attack [deg]
l = zeros(length(r), maxiter+1);%Chord [m]
l(:,1) = l_0; %initializes the matrix with the first try chord

while max(err)>toll && (counter-1)<=maxiter

    %Calculation of the blade area (Cavalieri - Simpson equation) with the
    %chord of the previous iterations
    S_bl = 0;
    if length(r)/2 ~= round ( length(r)/2 ) %odd number of sections
        for ii = 3 : 2 : length(r)
           S_bl = S_bl + ( (l(ii-2,counter-1) + l(ii,counter-1) + ...
               4*l(ii-1,counter-1)) )*(r(ii)-r(ii-2))/6;
        end
    else %even number of sections --> the last value is evaluated with the trapezes equation
        for ii = 3 : 2 : (length(r) - 1)
           S_bl = S_bl + ( (l(ii-2,counter-1) + l(ii,counter-1) +...
           4*l(ii-1,counter-1)) )*(r(ii)-r(ii-2))/6;
        end
           S_bl = S_bl + ( l(end,counter-1) +...
               l(end-1,counter-1) )*(r(end)-r(end-1))/2;
    end
    
    %aspect ratio
    AR = h^2/S_bl;
    
    %waitbar for the chord evaluating along the sections
    wait_bar = waitbar(0, ['Wait. Iterative cycle number n. ' num2str(counter-1) ' in progress...']);
    
    for section = 1:length(r) %cycle on the sections
    
        %Reynolds number
        Re(section, counter) = air.rho*w(section)*l(section,counter-1)/air.mu;

        %******* FIRST CYCLE ********

        %angle of attack in which Drag and Lift are evaluated
        alpha_input = alpha_struct.start:alpha_struct.cycle_1:alpha_struct.finish;

        %Recalling XFoil_launcher to evaluate Lift and Drag
        data_profile = XFoil_launcher(Re(section, counter), Ma(section), ...
            alpha_input, [blade.folder '/' char(blade.profiles(section))], visibility_Xfoil);

        Cl_Cd_ratio = data_profile.CL ./ data_profile.CD; % Lift / Drag ratio

        %finding the angle of attack that provides the best (max) Cl / Cd ratio
        alpha_opt = data_profile.Alpha(Cl_Cd_ratio==max(Cl_Cd_ratio)); 

        %******* SECOND CYCLE ********

        %angle of attack nearby the best solution found with the first cycle
        alpha_input = (alpha_opt-alpha_struct.cycle_1):alpha_struct.cycle_2:(alpha_opt+alpha_struct.cycle_1);

        %Recalling XFoil_launcher to evaluate Lift and Drag
        data_profile = XFoil_launcher(Re(section, counter), Ma(section), ...
            alpha_input, [blade.folder '/' char(blade.profiles(section))], visibility_Xfoil);

        Cl_Cd_ratio = data_profile.CL ./ data_profile.CD; % Lift / Drag ratio

        index = find(Cl_Cd_ratio==max(Cl_Cd_ratio));
        Cl(section, counter) = data_profile.CL(index);
        cd_2D = data_profile.CD(index);
        alpha(section, counter) = data_profile.Alpha(index);
        Cd(section, counter) = cd_2D + (Cl(section,counter)^2)/(pi*AR); %Cd with 3D correction

        %chord evaluation [m]
        l(section,counter) = (pi*r(section)/Nbl)*(c2^2/w(section)^2)*(8*a/(1-a))*1/...
            (Cl(section,counter)*sin(beta(section))+Cd(section, counter)*cos(beta(section)));

        waitbar(section/length(r),wait_bar); %waitbar update
    end
    close(wait_bar); %close the waitbar

    %calculate the max error (the max chord increment)
    err = max(abs(l(:,counter)-l(:,counter-1)));
    if (counter-1) == maxiter
        warning('Reach the max number of iterations')
    end
    counter = counter+1;
end

counter = counter - 1; %set the counter on the final blade designed

%% FOLDERS AND FILES FOR DATA SAVING

%if the folder doesn't exist the software will create it.
if exist('Report Design', 'dir')~=7
    mkdir('Report Design');
end

%current data and time
report.data = clock;
if report.data(2)<10
    report.month = ['0' num2str(report.data(2))];
else
    report.month = num2str(report.data(2));
end
if report.data(3)<10
    report.day = ['0' num2str(report.data(3))];
else
    report.day = num2str(report.data(3));
end
if report.data(4)<10
    report.hours = ['0' num2str(report.data(4))];
else
    report.hours = num2str(report.data(4));
end
if report.data(5)<10
    report.min = ['0' num2str(report.data(5))];
else
    report.min = num2str(report.data(5));
end
if report.data(6)<10
    report.sec = ['0' num2str(floor(report.data(6)))];
else
    report.sec = num2str(floor(report.data(6)));
end

%Design report folder
report.folder = ['Report Design/' num2str(report.data(1)) '-' report.month '-' ...
    report.day ' ' report.hours '-' report.min '-' report.sec ' - ' blade.name];
mkdir(report.folder); %create the folder

%creating the text file
report.file_name = [report.folder '/Design data.txt'];
report.fileID = fopen(report.file_name, 'w');

fprintf(report.fileID, 'PRELIMINARY DESIGN OF A HORIZONTAL WIND TURBINE BLADES\r\n\r\n');
fprintf(report.fileID, 'Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino\r\n');
fprintf(report.fileID, 'Software release: 1.0\r\n\r\n');
fprintf(report.fileID, 'Blade: %s \r\n\r\n', blade.name);
fprintf(report.fileID, 'Data: %d-%s-%s \r\n', report.data(1), report.month, report.day);
fprintf(report.fileID, 'Time: %s:%s:%s \r\n\r\n', report.hours, report.min, report.sec);
fprintf(report.fileID, 'Analysis data: \r\n');
fprintf(report.fileID, '   Rotor diameter: D = %.2f m \r\n', D);
fprintf(report.fileID, '   Induction factor: a = %.4f \r\n', a);
fprintf(report.fileID, '   Tip-speed ratio = %.2f \r\n', (omega*r(end)/c1));
fprintf(report.fileID, '   r/R ratio = %.2f \r\n', r_R);
fprintf(report.fileID, '   Undisturbed wind speed: c1 = %.2f m/s \r\n', c1);
fprintf(report.fileID, '   Speed rotation: omega = %.4f rad/s \r\n', omega);
fprintf(report.fileID, '   Tollerance on the chord increment: %.7f m\r\n', toll);
fprintf(report.fileID, '   Alpha start: %.2f \r\n', alpha_struct.start);
fprintf(report.fileID, '   Alpha finish: %.2f \r\n', alpha_struct.finish);
fprintf(report.fileID, '   Alpha first cycle: %.2f \r\n', alpha_struct.cycle_1);
fprintf(report.fileID, '   Alpha second cycle: %.2f \r\n\r\n', alpha_struct.cycle_2);


%% FIGURES PLOT

fig = figure;
for ii=1:length(r)
    plot(1:counter, l(ii, 1:counter), 'LineWidth', dim_lines_plot);
    hold on
    grid on
end
title('CHORD CONVERGENCE')
xlabel('Iterations')
ylabel('l [m]')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/Chord convergence.jpg'], 'jpg'); % standard jpg format
saveas(fig, [report.folder '/Chord convergence.fig'], 'fig'); % Matlab format

fig = figure;
plot(r, l(:,counter),'b-o', 'LineWidth', dim_lines_plot);
grid on
title('CHORD')
xlabel('r [m]')
ylabel('l [m]')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/Corda.jpg'], 'jpg');
saveas(fig, [report.folder '/Corda.fig'], 'fig');

fig = figure;
plot(r, alpha(:,counter),'b-o', 'LineWidth', dim_lines_plot);
grid on
title('ANGLE OF ATTACK')
xlabel('r [m]')
ylabel('\alpha [deg]')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/Angle of attack.jpg'], 'jpg');
saveas(fig, [report.folder '/Angle of attack.fig'], 'fig');

fig = figure;
subplot(311)
plot(r, Cl(:,counter),'b-o', 'LineWidth', dim_lines_plot);
grid on
title('LIFT')
xlabel('r [m]')
ylabel('CL')
ax = gca;
ax.FontSize = dim_text_plot;

subplot(312)
plot(r, Cd(:,counter),'b-o', 'LineWidth', dim_lines_plot);
grid on
title('DRAG')
xlabel('r [m]')
ylabel('CD')
ax = gca;
ax.FontSize = dim_text_plot;

subplot(313)
plot(r, Cl(:,counter)./Cd(:,counter),'b-o', 'LineWidth', dim_lines_plot);
grid on
title('Cl / Cd ratio')
xlabel('r [m]')
ylabel('CL/CD')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/Drag and Lift.jpg'], 'jpg');
saveas(fig, [report.folder '/Drag and Lift.fig'], 'fig');

%% FIGURE: PROFILES WITH PITCH ANGLE

fig = figure;
title('PROFILES WITH PITCH ANGLE')

pitch_angle = zeros(1,length(blade.profiles));

for jj = 1:length(blade.profiles)
    
    %data input from the profiles
    coordinates_profile = load([blade.folder '/' char(blade.profiles(section))]);
    x_profile = coordinates_profile(:,1);
    y_profile = coordinates_profile(:,2);

    %index of the min value of x_profiles
    index_x_min = find(x_profile == min(x_profile));

    %coordinate traslation in order to create a coincidence between the
    %center of the profile and the y axis
    x_profile = x_profile*l(jj,counter) - 0.5*l(jj,counter);
    y_profile = y_profile*l(jj,counter);

    %pitching angle of the section jj
    pitch_angle(jj) = beta_deg(jj)+ alpha(jj,counter);
    
    %section rotation
    for ii=1:length(x_profile)
        sol = [cosd(90-pitch_angle(jj)) -sind(90-pitch_angle(jj)); ...
                sind(90-pitch_angle(jj)) cosd(90-pitch_angle(jj))] * ...
                [x_profile(ii); y_profile(ii)];
        x_profile(ii) = sol(1);
        y_profile(ii) = sol(2);
    end

    line_plot(jj) = plot(x_profile, y_profile, 'LineWidth', 2);
    legend_text = char(blade.profiles(jj));
    legend_line{jj} = legend_text(1:end-4);
    axis equal
    grid on
    hold on
    %plot of the chord profile
    plot([x_profile(index_x_min) x_profile(1)], [y_profile(index_x_min) y_profile(1)], 'k--', 'LineWidth', 1.2)
    ax = gca; 
    ax.FontSize = 11;
    hold on
end

legend(line_plot, legend_line);
%figure save
saveas(fig, [report.folder '/Profiles with pitch angle.jpg'], 'jpg');
saveas(fig, [report.folder '/Profiles with pitch angle.fig'], 'fig');

%% PLOT 3D
fig = figure;
title('3D BLADE')

for jj = 1:length(blade.profiles)
    %data input from the profiles
    coordinates_profile = load([blade.folder '/' char(blade.profiles(section))]);
    x_profile = coordinates_profile(:,1);
    y_profile = coordinates_profile(:,2);
    
    %coordinate traslation in order to create a coincidence between the
    %center of the profile and the y axis, with reshaping of the profile
    %based on the chord dimension
    x_profile = x_profile*l(jj,counter) - 0.5*l(jj,counter);
    y_profile = y_profile*l(jj,counter);

    %pitching angle of the section jj
    pitch_angle(jj) = beta_deg(jj)+ alpha(jj,counter);
    
    %section rotation
    for ii=1:length(x_profile)
        sol = [cosd(90-pitch_angle(jj)) -sind(90-pitch_angle(jj)); ...
                sind(90-pitch_angle(jj)) cosd(90-pitch_angle(jj))] * ...
                [x_profile(ii); y_profile(ii)];
        x_profile(ii) = sol(1);
        y_profile(ii) = sol(2);
    end

    line_plot(jj) = plot3(x_profile, y_profile, (r(jj)*ones(length(x_profile),1)), 'LineWidth', 2);
    axis equal
    hold on
    legend_text = char(blade.profiles(jj));
    legend_line{jj} = legend_text(1:end-4);
   
    ax = gca;
    ax.FontSize = 11;
    hold on
end

legend(line_plot, legend_line)
%figure save
saveas(fig, [report.folder '/3D blade.jpg'], 'jpg');
saveas(fig, [report.folder '/3D blade.fig'], 'fig');

%% WIND TURBINE POWER

%power with trapezes integral
[P_trap, P_ideal, Cp_trap, P_sup_trap] = Power_trapezes(r, l(:,counter), beta, c1, w, Cl(:,counter), Cd(:,counter), air, omega, Nbl, efficiency, report, dim_text_plot);

%power with Cavalieri-Simpson integral
[P_cs, P_ideal, Cp_cs] = Power_cs(r, l(:,counter), beta, c1, w, Cl(:,counter), Cd(:,counter), air, omega, Nbl, efficiency, report, dim_text_plot, true);

%% OUTPUT PROFILES IN THE REPORT FILE

fprintf(report.fileID, 'Profiles of the blade used\r\n');
fprintf(report.fileID, 'section   -   profile\r\n');
for ii=1:length(blade.profiles) 
    section = char(blade.profiles(ii));
    fprintf(report.fileID, '   %d    -    %s \r\n', ii, section(1:end-4));
end

%% CLOSING REPORT FILE and saving analisys data

fclose(report.fileID); %closes the report

%deleting some unnecessary variables
clear fig ax wait_bar line_plot legend_line alpha_input alpha_opt ans cd_2D
clear coordinates_profile dim_lines_plot dim_text_plot h h_section ii
clear index jj legend_text section sol visibility_Xfoil
%saving all the variables in a Matlab file
save([report.folder '/Analysis_data.mat'])

%% SAVE THE FINAL BLADE DATA for the off-design and the pitching test

blade_design.l = l(:,counter); %chord for each section [m]
blade_design.Nbl = Nbl; %number of blades
blade_design.gamma = alpha(:,counter) + beta_deg'; %pitch angle [deg]
blade_design.r = r; %radial coordinate (distance from the axis of rotation) [m]
blade_design.folder = blade.folder; %folder with the profiles
blade_design.profiles = blade.profiles; %blade profiles
blade_design.name = blade.name; %blade name (label)
blade_design.omega = omega; %rotational speed [rad/s]
blade_design.AR = AR; %Aspect Ratio
blade_design.S = S_bl; %Blade area [m^2]
blade_design.efficiency = efficiency; %Mechanical and electrical wind turbine efficiency
blade_design.a_design = a; %Designed induction factor

save([report.folder '/Blade_Design_data.mat'], 'blade_design') 
end

