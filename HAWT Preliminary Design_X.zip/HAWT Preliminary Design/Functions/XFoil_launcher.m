function [data] = XFoil_launcher(Re, Ma, alpha_input, profile_name, visibility_Xfoil)
% Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This function lauch XFoil with the input selected
%
% This function is a revision of the script "exampleXFOIL.m" enclosed with
% the XFOIL - MATLAB interface developed by Rafael Oliveira.

%% Create a new instance of the XFOIL class, and set some properties
xf = XFOIL;
xf.KeepFiles = false; % Set it to true to keep all intermediate files created (Airfoil, Polars, ...)
xf.Visible = visibility_Xfoil;    % Set it to false to hide XFOIL plotting window

%% Set the profile
xf.Airfoil =  Airfoil(profile_name);

%% Setup the action list

%Add five filtering steps to smooth the airfoil coordinates and help convergence
xf.addFiltering(5);

%Switch to OPER mode, and set Reynolds and Mach 
xf.addOperation(Re, Ma);

%Set maximum number of iterations
xf.addIter(100)

%Initializate the calculations
xf.addAlpha(0,true);

%Create a new polar
xf.addPolarFile('Polar.txt');

% Set the sequence of angle of attack
xf.addAlpha(alpha_input);

%Close the polar file
xf.addClosePolarFile;

%And finally add the action to quit XFOIL
xf.addQuit;

%% Now we're ready to run XFOIL
xf.run
%disp('Running XFOIL, please wait...')

%% Wait up to 1 seconds for it to finish... 
%It is possible to run more than one XFOIL instance at the same time
finished = xf.wait(100); 

%% If successfull, read and plot the polar
if finished
    %disp('XFOIL analysis finished.')
    xf.readPolars;
    %figure
    %xf.plotPolar(1);
else
    xf.kill;
end

data = xf.Polars{1,1};

end
