%% PITCHING HORIZONTAL AXIS WIND TURBINE BLADES
%
% Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino
%
% Data: October 14, 2017
% Release: 1.0
%
% This coda was developed during the curse of "Machines" in the bachelor
% level of Mechanic Engineering at Politecnico di Milano. It also uses 
% XFOIL - MATLAB interface developed by Rafael Oliveira.
%
% This code calculate the power produced by a wind turbine in off-design
% conditions. You have to copy in the Current Folder the Matlab file
% "Blade_Design_data.mat" created with the Design script, this file 
% contains all the blade design informations. You can set the off-design 
% wind speed and the other variables to calculate the power produced. 

clear variables
close all
clc

addpath('Functions')

disp('PRELIMINARY DESIGN OF HORIZONTAL WIND TURBINE BLADES')
disp('Pitching')
disp(' ')
disp('Author: Oboe Daniele, Marinomi Andrea and Mastrandrea Sabino')
disp('Release: 1.0')
disp(' ')

%% USER INPUT
% These inputs must be setted by the user

c1 = 8:0.5:15; %off - design undisturbed wind speed [m/s]

toll = 0.001; %tollerance on the induction factor increment
maxiter = 50; %max number of iterations for the induction factor calculation
max_errors = 6; %max number of errors due to XFoil convergence for each cycle

%Air features
air.gamma = 1.4; % gamma = Cp / Cv
air.R = 287; %gas constant
air.T = 273.15+15; %ait temperature [K]
air.rho = 1.1162; %air density [kg/m^3]
air.mu = 1.75e-5; %air viscosity [kg * s / m]

P_lim = 1e6; %Power limit: the max electrical power that the wind turbine can produce [W]
n_partitions = 10; %number of partitions for the power limit calculation with the bisection algorithm

%delta pitch angle: this angle is the variation of the angle of attack compared
%to the design angle of attack. This is a rigid rotation of the all blade
%sections
delta_pitch_angle.start = -10; %start value for the pitch angle
delta_pitch_angle.finish = 1; %finish value for the pitch angle
delta_pitch_angle.cycle_1 = 1; %step of the first cycle (we suggest to use 1 as step)
delta_pitch_angle.cycle_2 = 0.2; %step of the second cycle: this value must be a
        %submultiple of the first cycle step (we suggest to use one of the
        %following values: 0.1, 0.2, 0.25)

visibility_Xfoil = false;
%false = do not show the XFoil window
%true = show the XFoil window

dim_text_plot = 14; %text dimension of the plot axis, title and legend
dim_lines_plot = 2; %plot lines thickness 

%% AUTOMATIC INPUT
% These inputs must NOT be setted by the user

%load the blade data
load('Blade_Design_data.mat');

%associate the blade bata loaded to the current variables for the script
blade.folder = blade_design.folder; %folder that contains the profiles
blade.name = blade_design.name; %name of the blade
blade.profiles = blade_design.profiles; %profiles in array and linspaced 
                                        %from the hub to the tip
l = blade_design.l; %chord [m]
Nbl = blade_design.Nbl; %number of blades
gamma = blade_design.gamma; %angle of design pitch [deg]
r = blade_design.r; %radius of each section fron the axis of rotation [m]
omega = blade_design.omega; %rotation speed [rad/s]
AR = blade_design.AR; %aspect ratio
S_blade = blade_design.S; %blade area [m^2]
efficiency = blade_design.efficiency; %mechanical and electrical efficiency
a_design = blade_design.a_design; %design induction factor

u = omega*r; %periferical speed [m/s]

D = 2*r(end); %wind turbine diameter [m]

%% PRE - ANALYSIS CHECKS

%check if the blase folder exist
if exist(blade.folder, 'dir')~=7
    error('Error: the blade folder selected do not exist')
end

%check if all the profiles exist inside the blade folder
for ii=1:length(blade.profiles)
    if exist([blade.folder '/' char(blade.profiles(ii))], 'file')~=2
        error(['Error: Profile ' char(blade.profiles(ii)) ' is missing from the folder'])
    end
end

%% FOLDER AND FILE FOR DATA SAVING

%if the folder do not exist the software will create it.
if exist('Report Pitching', 'dir')~=7
    mkdir('Report Pitching');
end

%current data and time
report.data = clock;
if report.data(2)<10
    report.month = ['0' num2str(report.data(2))];
else
    report.month = num2str(report.data(2));
end
if report.data(3)<10
    report.day = ['0' num2str(report.data(3))];
else
    report.day = num2str(report.data(3));
end
if report.data(4)<10
    report.hours = ['0' num2str(report.data(4))];
else
    report.hours = num2str(report.data(4));
end
if report.data(5)<10
    report.min = ['0' num2str(report.data(5))];
else
    report.min = num2str(report.data(5));
end
if report.data(6)<10
    report.sec = ['0' num2str(floor(report.data(6)))];
else
    report.sec = num2str(floor(report.data(6)));
end

%Design report folder
report.folder = ['Report Pitching/' num2str(report.data(1)) '-' report.month '-' ...
    report.day ' ' report.hours '-' report.min '-' report.sec ' - ' blade.name];
mkdir(report.folder); %create the folder

%create the text file
report.file_name = [report.folder '/Pitching data.txt'];
report.fileID = fopen(report.file_name, 'w');

fprintf(report.fileID, 'PITCHING REPORT ANALYSIS\r\n\r\n');
fprintf(report.fileID, 'Author: Oboe Daniele, Marinoni Andrea and Mastrandrea Sabino\r\n\r\n');
fprintf(report.fileID, 'Software release: 1.0\r\n\r\n');
fprintf(report.fileID, 'Blade: %s \r\n\r\n', blade.name);
fprintf(report.fileID, 'Data: %d-%s-%s \r\n', report.data(1), report.month, report.day);
fprintf(report.fileID, 'Time: %s:%s:%s \r\n\r\n', report.hours, report.min, report.sec);
fprintf(report.fileID, 'Analysis data: \r\n');
fprintf(report.fileID, '   Rotor diameter: D = %.2f m \r\n', D);
fprintf(report.fileID, '   r/R ratio = %.2f \r\n', r(1)/r(end));
fprintf(report.fileID, '   Power limit: P = %.3f kW \r\n', P_lim/1000);
fprintf(report.fileID, '   Speed rotation: omega = %.4f rad/s \r\n', omega);
fprintf(report.fileID, '   Tollerance on the chord increment: %.7f m\r\n', toll);
fprintf(report.fileID, '   Max number of iterations for the chord: %d m\r\n', maxiter);
fprintf(report.fileID, '   Number of partition for the power limit: %d m \r\n\r\n', n_partitions);

%% CALCULATE THE INDUCTION FACTOR IN EACH SECTION

P_opt = zeros(1, length(c1));
Cp_opt = zeros(1, length(c1));
pitch_angle_opt = zeros(1, length(c1));
Cl_opt = zeros(length(r), length(c1));
Cd_opt = zeros(length(r), length(c1));
a_opt = zeros(length(r), length(c1));
Re_opt = zeros(length(r), length(c1));
Ma_opt = zeros(length(r), length(c1));

for wind_speed_test = 1:length(c1)
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %first cycle of the pitch angle
    delta_gamma = delta_pitch_angle.start:delta_pitch_angle.cycle_1:delta_pitch_angle.finish;
    
    a_od = zeros(length(r), length(delta_gamma));
    Re = zeros(length(r), length(delta_gamma));
    Cl = zeros(length(r), length(delta_gamma));
    Cd = zeros(length(r), length(delta_gamma));
    w = zeros(length(r), length(delta_gamma));
    Ma = zeros(length(r), length(delta_gamma));
    beta = zeros(length(r), length(delta_gamma));
    alpha = zeros(length(r), length(delta_gamma));
    P = zeros(length(delta_gamma), 1);
    Cp = zeros(length(delta_gamma), 1);
    
    wait_bar = waitbar(0, ['Wait. Wind speed ' num2str(wind_speed_test) ' of ' num2str(length(c1)) ', cycle 1 of 2.']);
    for jj = 1:length(delta_gamma) %one cycle for each pitch angle
        
        gamma_pitching = gamma + delta_gamma(jj); %pitch angle for each section
        
        for ii = 1:length(r)
            %calculate the induction factor for each section
            [a_od(ii,jj), Re(ii,jj), Cl(ii,jj), Cd(ii,jj), w(ii,jj), Ma(ii,jj), beta(ii,jj), alpha(ii,jj)] = Induction_factor(toll, maxiter, l(ii), c1(wind_speed_test), u(ii), r(ii), air, blade, gamma_pitching(ii), ii, a_design, Nbl, AR, visibility_Xfoil, max_errors);
        end
        
        %calculate the wind turbine power with Cavalieri-Simpson integral
        [P(jj), P_ideal, Cp(jj)] = Power_cs(r, l, beta(:,jj)*pi/180, c1(wind_speed_test), w(:,jj), Cl(:,jj), Cd(:,jj), air, omega, Nbl, efficiency, report, dim_text_plot, false);
        
        waitbar(jj/length(delta_gamma),wait_bar); %upgrade the waitbar
    end
    close(wait_bar)
    
    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 1']);
    subplot(211)
    plot(delta_gamma, P/1000,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('P [kW]')
    title('POWER')
    ax = gca;
    ax.FontSize = dim_text_plot;
    subplot(212)
    plot(delta_gamma, Cp,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('Cp')
    title('Cp')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1.jpg'], 'jpg');
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1.fig'], 'fig');
    
    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 1']);
    plot(delta_gamma, P/1000,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('P [kW]')
    title('POWER')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1 - P.jpg'], 'jpg');
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1 - P.fig'], 'fig');
    
    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 1']);
    plot(delta_gamma, Cp,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('Cp')
    title('Cp')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1 - Cp.jpg'], 'jpg');
    saveas(fig, [report.folder '/pitching_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 1 - Cp.fig'], 'fig');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %second cycle of the pitch angle    
    if max(P) < P_lim %find the the max power
        
        delta_gamma_opt = delta_gamma(Cp == max(Cp));
        delta_gamma = (delta_gamma_opt - delta_pitch_angle.cycle_1):delta_pitch_angle.cycle_2:(delta_gamma_opt + delta_pitch_angle.cycle_1);
        
        a_od = zeros(length(r), length(delta_gamma));
        Re = zeros(length(r), length(delta_gamma));
        Cl = zeros(length(r), length(delta_gamma));
        Cd = zeros(length(r), length(delta_gamma));
        w = zeros(length(r), length(delta_gamma));
        Ma = zeros(length(r), length(delta_gamma));
        beta = zeros(length(r), length(delta_gamma));
        alpha = zeros(length(r), length(delta_gamma));
        P = zeros(length(delta_gamma), 1);
        Cp = zeros(length(delta_gamma), 1);
        
        wait_bar = waitbar(0, ['Wait. Wind speed ' num2str(wind_speed_test) ' of ' num2str(length(c1)) ', cycle 2 of 2.']);
        for jj = 1:length(delta_gamma) %one cycle for each pitch angle
            gamma_pitching = gamma + delta_gamma(jj); %pitch angle for each section
            for ii = 1:length(r)
                %calculate the induction factor for each section
                [a_od(ii,jj), Re(ii,jj), Cl(ii,jj), Cd(ii,jj), w(ii,jj), Ma(ii,jj), beta(ii,jj), alpha(ii,jj)] = Induction_factor(toll, maxiter, l(ii), c1(wind_speed_test), u(ii), r(ii), air, blade, gamma_pitching(ii), ii, a_design, Nbl, AR, visibility_Xfoil, max_errors);
            end
            %calculate the wind turbine power with CAvalieri-Simpson integral
            [P(jj), P_ideal, Cp(jj)] = Power_cs(r, l, beta(:,jj)*pi/180, c1(wind_speed_test), w(:,jj), Cl(:,jj), Cd(:,jj), air, omega, Nbl, efficiency, report, dim_text_plot, false);
            waitbar(jj/length(delta_gamma),wait_bar); %upgrade the waitbar
        end
        close(wait_bar);

        index = find(Cp == max(Cp));

    else %find the pitch angle to produce the max power allowed
        if min(P) < P_lim
            %Intervals for the bisection algorithm
            P_high = min(P(P>P_lim));
            P_low = max(P(P<P_lim));
            
            delta_gamma_high = delta_gamma(P == P_high);
            delta_gamma_low = delta_gamma(P == P_low);
            
            a_od = zeros(length(r), n_partitions);
            Re = zeros(length(r), n_partitions);
            Cl = zeros(length(r), n_partitions);
            Cd = zeros(length(r), n_partitions);
            w = zeros(length(r), n_partitions);
            Ma = zeros(length(r), n_partitions);
            beta = zeros(length(r), n_partitions);
            alpha = zeros(length(r), n_partitions);
            P = zeros(n_partitions, 1);
            Cp = zeros(n_partitions, 1);
            delta_gamma = zeros(n_partitions, 1);

            wait_bar = waitbar(0, ['Wait. Wind speed ' num2str(wind_speed_test) ' of ' num2str(length(c1)) ', cycle 2 of 2.']);
            for jj = 1:n_partitions %bisection cycle
                
                %set the delta pitch angle with the bisection criteria
                delta_gamma(jj) = ( delta_gamma_high + delta_gamma_low )/2;
                
                gamma_pitching = gamma + delta_gamma(jj); %pitch angle for each section
                for ii = 1:length(r)
                    %calculate the induction factor for each section
                    [a_od(ii,jj), Re(ii,jj), Cl(ii,jj), Cd(ii,jj), w(ii,jj), Ma(ii,jj), beta(ii,jj), alpha(ii,jj)] = Induction_factor(toll, maxiter, l(ii), c1(wind_speed_test), u(ii), r(ii), air, blade, gamma_pitching(ii), ii, a_design, Nbl, AR, visibility_Xfoil, max_errors);
                end
                %calculate the wind turbine power with Cavalieri-Simpson integral
                [P(jj), P_ideal, Cp(jj)] = Power_cs(r, l, beta(:,jj)*pi/180, c1(wind_speed_test), w(:,jj), Cl(:,jj), Cd(:,jj), air, omega, Nbl, efficiency, report, dim_text_plot, false);
                waitbar(jj/length(delta_gamma),wait_bar); %upgrade the waitbar
                
                if P(jj) > P_lim
                    P_high = P(jj);
                    delta_gamma_high = delta_gamma(jj);
                else % P(jj) < P_lim
                    P_low = P(jj);
                    delta_gamma_low = delta_gamma(jj);      
                end
                
            end
            close(wait_bar);
            index = find(P == max(P(P<P_lim)));
        
        else % min(P) > P_lim
            index = find(P == min(P));
            warning('The pitch angle range used can''t limit the power to the max power allowed')
        end
        
    end
    
    Cp_opt(wind_speed_test) = Cp(index);
    P_opt(wind_speed_test) = P(index);
    pitch_angle_opt(wind_speed_test) = delta_gamma(index);
    Cl_opt(:, wind_speed_test) = Cl(:, index);
    Cd_opt(:, wind_speed_test) = Cd(:, index);
    a_opt(:, wind_speed_test) = a_od(:, index);
    Re_opt(:, wind_speed_test) = Re(:, index);
    Ma_opt(:, wind_speed_test) = Ma(:, index);

    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 2']);
    subplot(311)
    plot(r, a_opt(:, wind_speed_test),'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('R [m]')
    ylabel('a')
    title('INDUCTION FACTOR')
    ax = gca;
    ax.FontSize = dim_text_plot;
    subplot(312)
    plot(delta_gamma, P/1000,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('P [kW]')
    title('POWER')
    ax = gca;
    ax.FontSize = dim_text_plot;
    subplot(313)
    plot(delta_gamma, Cp,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('Cp')
    title('Cp')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2.jpg'], 'jpg');
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2.fig'], 'fig');

    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 2']);
    plot(r, a_opt(:, wind_speed_test),'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('R [m]')
    ylabel('a')
    title('INDUCTION FACTOR')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - a.jpg'], 'jpg');
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - a.fig'], 'fig');

    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 2']);
    plot(delta_gamma, P/1000,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('P [kW]')
    title('POWER')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - P.jpg'], 'jpg');
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - P.fig'], 'fig');

    fig = figure('Name', ['wind speed = ' num2str(c1(wind_speed_test)) ' m/s - cycle 2']);
    plot(delta_gamma, Cp,'b-o', 'LineWidth', dim_lines_plot);
    grid on
    xlabel('\Delta \gamma [deg]')
    ylabel('Cp')
    title('Cp')
    ax = gca;
    ax.FontSize = dim_text_plot;
    %figure save
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - Cp.jpg'], 'jpg');
    saveas(fig, [report.folder '/picking_ c1 ' num2str(c1(wind_speed_test)) ' ms_ cycle 2 - Cp.fig'], 'fig');

   
end

%% PLOT

fig = figure('Name', 'PICKING');
subplot(311)
plot(c1, pitch_angle_opt,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('\Delta \gamma [deg]')
title('DELTA PITCH ANGLE')
ax = gca;
ax.FontSize = dim_text_plot;
subplot(312)
plot(c1, P_opt/1000,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('P [kW]')
title('POWER')
ax = gca;
ax.FontSize = dim_text_plot;
subplot(313)
plot(c1, Cp_opt,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('Cp')
title('Cp')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/pitching.jpg'], 'jpg');
saveas(fig, [report.folder '/pitching.fig'], 'fig');

fig = figure('Name', 'PICKING');
plot(c1, pitch_angle_opt,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('\Delta \gamma [deg]')
title('DELTA PITCH ANGLE')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/pitching - delta pitch angle.jpg'], 'jpg');
saveas(fig, [report.folder '/pitching - delta pitch angle.fig'], 'fig');

fig = figure('Name', 'PICKING');
plot(c1, P_opt/1000,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('P [kW]')
title('POWER')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/pitching - P.jpg'], 'jpg');
saveas(fig, [report.folder '/pitching - P.fig'], 'fig');

fig = figure('Name', 'PICKING');
plot(c1, Cp_opt,'b-o', 'LineWidth', dim_lines_plot);
grid on
xlabel('c1 [m/s]')
ylabel('Cp')
title('Cp')
ax = gca;
ax.FontSize = dim_text_plot;
%figure save
saveas(fig, [report.folder '/pitching - Cp.jpg'], 'jpg');
saveas(fig, [report.folder '/pitching - Cp.fig'], 'fig');


%% PROFILES OUTPUT IN THE REPORT FILE

fprintf(report.fileID, 'Profiles of the blade used\r\n');
fprintf(report.fileID, 'section   -   profile\r\n');
for ii=1:length(blade.profiles) 
    section = char(blade.profiles(ii));
    fprintf(report.fileID, '   %d    -    %s \r\n', ii, section(1:end-4));
end

%% END FUNCTION

fclose(report.fileID); %close the report file

%delete some unnecessary variables
clear a_od alpha ans ax Cd Cl Cp delta_gamma fig ii jj Ma Re section w 
clear wait_bar wind_speed_test
%save all the variables on a Matlab file
save([report.folder '/Analysis_data.mat']) 


